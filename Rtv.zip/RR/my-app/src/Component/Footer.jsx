import React from 'react'

function Footer() {
    return (
        <>
            <div className=' bg-slate-200 w-[100%]'>
                <h2 className='text-center text-2xl py-2 font-serif'>my name is footer page</h2>
            </div>
        </>
    )
}

export default Footer
