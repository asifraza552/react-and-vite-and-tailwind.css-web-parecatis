// import React from 'react'
import {useState,React} from 'react'

function Home() {

    const [Count , setCount] = useState(0);

    return (
        <>
            <div className='w-[70%] bg-slate-100 float-end h-[80vh] px-5 pt-16'>
                <h1 className='text-3xl font-serif'>Lorem ipsum dolor <br></br> sit amet<br></br> 
                ( {Count} )</h1>
                <p className='capitalize font-serif py-5'>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Similique consectetur voluptates totam voluptatibus excepturi!
                    Reprehenderit doloribus, eligendi qui delectus nostrum atque fugiat
                    dolorum natus cum facilis molestias! Nulla eveniet amet cupiditate rerum
                    sed beatae libero consequuntur voluptatem necessitatibus commodi, praesentium
                    corrupti nesciunt facere blanditiis quisquam pariatur.</p>
                <div className='flex gap-5 pt-5'>
                    <button
                    onClick={() => setCount (Count + 1) }
                     type="button" className="text-white bg-gradient-to-r from-green-400 via-green-500 to-green-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-green-300 dark:focus:ring-green-800 font-serif font-bold rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2">icaremint</button>
                    <button
                     onClick={() => setCount (Count - 1) }
                    type="button" className="text-white bg-gradient-to-r from-green-400 via-green-500 to-green-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-green-300 dark:focus:ring-green-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2">decaremint</button>
                </div>

            </div>
        </>
    )
}

export default Home
