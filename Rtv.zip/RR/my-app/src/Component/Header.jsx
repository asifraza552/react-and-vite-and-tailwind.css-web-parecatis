import React from 'react'
import { Link } from 'react-router-dom'

function Header() {
    return (
        <>
            <header className=' bg-slate-200 w-[100%] '>
                <ul className='flex justify-between font-serif font-bold px-5 py-2'>
                    <div>logo</div>
                    <div className='flex gap-5'>
                        <li>
                            <Link to="/">Home</Link>
                        </li>
                        <li>
                            <Link to="/About">About</Link>
                        </li>
                        <li>
                            <Link to="/Contact">contact</Link>
                        </li>
                    </div>
                </ul>
            </header>

        </>
    )
}

export default Header
