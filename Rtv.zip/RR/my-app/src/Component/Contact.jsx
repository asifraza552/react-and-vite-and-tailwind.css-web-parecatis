import React from 'react'

function Contact() {
    return (
        <>
            <div className='w-[100%] h-[80vh] bg-slate-100 flex justify-center pt-40'>
                <h1 className='text-5xl text-green-500 capitalize font-serif'>( my name is contant page )</h1>
            </div>
        </>
    )
}

export default Contact
