import React from 'react'

function Sidebar() {
  return (
    <>
    <div className='w-[30%] h-[80vh] bg--100 bg-slate-300'>
        <h1 className='text-5xl font-serif py-5'>side bar</h1>
    </div>
      
    </>
  )
}

export default Sidebar
