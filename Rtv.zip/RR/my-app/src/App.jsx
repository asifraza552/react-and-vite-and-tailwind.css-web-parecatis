// import { useState } from 'react'
import './App.css'
import {BrowserRouter,Routes,Route} from "react-router-dom";
import Home from './Component/Home';
import About from './Component/About';
import Contact from './Component/Contact';
import Footer from './Component/Footer';
import Header from './Component/Header';
import Sidebar from './Component/Sidebar';

function App() {

  return (
    <>
     <BrowserRouter>
     <Header/>
     <div className='flex'>
     <Sidebar/>

     <Routes>
      <Route path='/' element={<Home/>} />
      <Route path='/About' element={<About/>} />
      <Route path='/Contact' element={<Contact/>} />
      <Route path='/Footer' element={<Footer/>} />
     </Routes>
     </div>
     <Footer/>
     </BrowserRouter> 
    </>
  )
}

export default App
